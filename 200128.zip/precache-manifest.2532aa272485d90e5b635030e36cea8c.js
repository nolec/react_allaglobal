self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a5d1cd6f81c693bed0c2c97b22fd8784",
    "url": "/index.html"
  },
  {
    "revision": "cc514ed6ffe8c992d7fb",
    "url": "/static/css/2.e315d21c.chunk.css"
  },
  {
    "revision": "1ffb76df6861006687b8",
    "url": "/static/css/main.eea9c656.chunk.css"
  },
  {
    "revision": "cc514ed6ffe8c992d7fb",
    "url": "/static/js/2.0c4da9c5.chunk.js"
  },
  {
    "revision": "1ffb76df6861006687b8",
    "url": "/static/js/main.a22d6976.chunk.js"
  },
  {
    "revision": "6fa33295112204280ad4",
    "url": "/static/js/runtime-main.f86f1cb4.js"
  },
  {
    "revision": "960dc680cee13a5544c8a5e00349e47c",
    "url": "/static/media/1.960dc680.png"
  },
  {
    "revision": "151662d74d56289aafc3afb008cac54a",
    "url": "/static/media/AllA_Whitepaper_KR_1.0.134c5d76.pdf"
  },
  {
    "revision": "92ed31bdc33112a84c103b4ddc7775a9",
    "url": "/static/media/X-Mockup.92ed31bd.png"
  },
  {
    "revision": "c8ac722f84254080e33f19e50534dd49",
    "url": "/static/media/alla_app_video.c8ac722f.mp4"
  },
  {
    "revision": "b1056182e106e48b5273d0a94fca5668",
    "url": "/static/media/alla_logo.b1056182.svg"
  },
  {
    "revision": "30c03ffcf66db4b3deb7818a13bd31b3",
    "url": "/static/media/alla_second_contents_mockup.30c03ffc.png"
  },
  {
    "revision": "f27883a1858891f96cb4a49d083afebe",
    "url": "/static/media/apple_btn.f27883a1.svg"
  },
  {
    "revision": "d5fe6ff82f28f4e40d7fb4ea33f9af9b",
    "url": "/static/media/artboard.d5fe6ff8.png"
  },
  {
    "revision": "f341b393f8a1657a4f8c0dd23540c773",
    "url": "/static/media/bg2.f341b393.png"
  },
  {
    "revision": "cca0464d5922f18c4df790b75046bc9e",
    "url": "/static/media/browser_icon.cca0464d.svg"
  },
  {
    "revision": "cc3bcdc2e1a1d3d532725dd17b55e253",
    "url": "/static/media/download_btn.cc3bcdc2.svg"
  },
  {
    "revision": "80cb6ab9c4e93965b407c41491897072",
    "url": "/static/media/download_btn1.80cb6ab9.svg"
  },
  {
    "revision": "8a0dba7ec05f5c652b0b2e5c77509a76",
    "url": "/static/media/google_btn.8a0dba7e.svg"
  },
  {
    "revision": "8228acf0f511c376f637ecf40ee327bf",
    "url": "/static/media/header_down_btn.8228acf0.svg"
  },
  {
    "revision": "8881d34deb164e57ea4e9727a457c60b",
    "url": "/static/media/img_1.8881d34d.png"
  },
  {
    "revision": "1c51685ce8bacd731b0b4b143330ee51",
    "url": "/static/media/img_2.1c51685c.png"
  },
  {
    "revision": "6dfc279e75eb2b8b3b90e12def696727",
    "url": "/static/media/img_2_1.6dfc279e.png"
  },
  {
    "revision": "bb1002a536cab2ba38f00bbbca4779bc",
    "url": "/static/media/img_3.bb1002a5.png"
  },
  {
    "revision": "f85a7ff642bea1fca92d7940fd75f9e1",
    "url": "/static/media/img_3_1.f85a7ff6.png"
  },
  {
    "revision": "0a130b65cb87f77b4837dcf76da31bc9",
    "url": "/static/media/img_4.0a130b65.png"
  },
  {
    "revision": "3833320fb0d154e820a2a397b2daf256",
    "url": "/static/media/img_5.3833320f.png"
  },
  {
    "revision": "561982024a2f7d049a3af083910e3efa",
    "url": "/static/media/img_6.56198202.png"
  },
  {
    "revision": "1995a741bac3ebeeab89cbe5ed499220",
    "url": "/static/media/img_7.1995a741.png"
  },
  {
    "revision": "a5d01b4c9dda1e5fd7a88f1eba204b15",
    "url": "/static/media/iphone_m.a5d01b4c.png"
  },
  {
    "revision": "700e46c1f27e33b0f59a944a156df999",
    "url": "/static/media/line_group.700e46c1.png"
  },
  {
    "revision": "0d63081a0dbe38a0557443a0b5e94542",
    "url": "/static/media/m_1.0d63081a.png"
  },
  {
    "revision": "c04cf694f97a4c925e71bb5ed329a186",
    "url": "/static/media/m_2.c04cf694.png"
  },
  {
    "revision": "07f62e9d151d06f4f9937d3bf7f74831",
    "url": "/static/media/m_3.07f62e9d.png"
  },
  {
    "revision": "c68bb679d780b8aa27fb465b4afb7e72",
    "url": "/static/media/market_1.c68bb679.png"
  },
  {
    "revision": "408ae26f3fa0ca4676aa576203177aa6",
    "url": "/static/media/market_2.408ae26f.png"
  },
  {
    "revision": "2d401e75642169b7b090167e6bfde209",
    "url": "/static/media/market_3.2d401e75.png"
  },
  {
    "revision": "fd1654988fdf00bc270aa79f646756b5",
    "url": "/static/media/market_4.fd165498.png"
  },
  {
    "revision": "08ee2f33c5ef3eaaaa209cfd0abe8dd9",
    "url": "/static/media/market_5.08ee2f33.png"
  },
  {
    "revision": "0dc65eab91f74361fbb6a423c2382e28",
    "url": "/static/media/market_icon.0dc65eab.svg"
  },
  {
    "revision": "33263ea49b424565986fb32539707520",
    "url": "/static/media/mining_icon.33263ea4.svg"
  },
  {
    "revision": "f2f0c9c2bedfb230c967dec811c62377",
    "url": "/static/media/mmarket_1.f2f0c9c2.png"
  },
  {
    "revision": "2874f49ed7163522d9cd36ed7845ca79",
    "url": "/static/media/mmarket_2.2874f49e.png"
  },
  {
    "revision": "2b0234c7d9ea103b8e70e70f5948c7c9",
    "url": "/static/media/mmarket_3.2b0234c7.png"
  },
  {
    "revision": "0c86db8e46c856fa2cc0f3402e752972",
    "url": "/static/media/notopen_numbers.0c86db8e.ttf"
  },
  {
    "revision": "eb2c2fdfb362bee998d05b41b3873c99",
    "url": "/static/media/pass.eb2c2fdf.png"
  },
  {
    "revision": "739c2e7fbd6e3fc5d73146668b00b1d3",
    "url": "/static/media/privacy_policy_AllA.pdf"
  },
  {
    "revision": "c554266e3d9e09a39c1d1178716d0ba6",
    "url": "/static/media/service_icon.c554266e.svg"
  },
  {
    "revision": "6c820c02e870541e2d1f07639b20b704",
    "url": "/static/media/terms_conditions_AllA.pdf"
  },
  {
    "revision": "fbaa7f46b3d1bb0ba26145204a770e0f",
    "url": "/static/media/video_icon.fbaa7f46.svg"
  },
  {
    "revision": "d3e7cf8eba0c70ebddaf388b6201efa9",
    "url": "/static/media/video_img1.d3e7cf8e.png"
  }
]);